package SDALab8.task4;

import java.util.Iterator;

public abstract class Object_Component{
      abstract Iterator createIterator();
      public abstract void render();
      public abstract float volume();
}