package lab8.task3;

import java.util.Iterator;

public interface Menu {
	public Iterator createIterator();
}
