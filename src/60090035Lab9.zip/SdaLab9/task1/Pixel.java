package SdaLab9.task1;

public class Pixel {
    int x1;
    int y1;
    Pixel(int x1,int y1){
        this.x1 = x1;
        this.y1 = y1;
    }
}
