package SdaLab9.task1;

public class Arc {

   public int x;
   public int y;
   public int r;

   public Arc(int x, int y, int r) {
     this.x = x;
     this.y = y;
     this.r = r;
   }

}
